const String EventToggleTabBarIndex = 'EventToggleTabBarIndex';

const String EventVideoPlayPosition = "EventVideoPlayPosition";
