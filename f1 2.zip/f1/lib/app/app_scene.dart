import 'package:flutter/material.dart';
import 'package:tianyue/app/guide_scene.dart';
import 'package:tianyue/public.dart';
import 'package:tianyue/SQL/book.dart';
import 'package:device_info/device_info.dart';
import 'dart:io';


class AppScene extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<AppScene> {
  String _platformImei = 'Unknown';

  @override
  void initState() {
    super.initState();
    getDeviceInfo();
  }
  void getDeviceInfo() async {
    DeviceInfoPlugin deviceInfo = new DeviceInfoPlugin();
    if(Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      print('1');
    } else if (Platform.isIOS) {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      print('2');
    }
  }

  @override
  Widget build(BuildContext context) {
    ///初始化
    SqlBookDate.sharedInstance().OnAllSQLData();
    return MaterialApp(
      title: 'tianyue',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.white,
        dividerColor: Color(0xffeeeeee),
        scaffoldBackgroundColor: TYColor.paper,
        textTheme: TextTheme(body1: TextStyle(color: TYColor.darkGray)),
      ),
      home: GuideScene(),
    );
  }
}


///先加载搜索信息
class SqlBookDate {

  // 单例公开访问点
  factory SqlBookDate() =>sharedInstance();

  // 静态私有成员，没有初始化
  static SqlBookDate _instance = SqlBookDate._();

  // 私有构造函数
  SqlBookDate._() {
    // 具体初始化代码
  }

  // 静态、同步、私有访问点
  static SqlBookDate sharedInstance() {
    return _instance;
  }

  BookSqlite bookSqlite = new BookSqlite();
  List SqlAllList;


  ///获取全部搜索历史记录
  OnAllSQLData()async{
    await  bookSqlite.openSqlite();
    List alllist= await bookSqlite.queryAll();
    SqlAllList=alllist;

  }
  //获取编号为1的书
  void getBookName() async{
    await bookSqlite.openSqlite();
    Book book = await bookSqlite.getBook(1);
 //   await bookSqlite.close();
    List asd= await bookSqlite.queryAll();

  }
}

