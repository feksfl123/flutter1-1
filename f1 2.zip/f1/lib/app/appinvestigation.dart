import 'dart:math';

import 'package:flutter/material.dart';
import 'package:english_words/english_words.dart';
import 'package:flutter/rendering.dart';
import 'package:tianyue/SQL/book.dart';
import 'app_scene.dart';
import 'app_navigator.dart';
import 'package:tianyue/ranking/Pulltorefresh.dart';


class appInvestigation extends StatefulWidget {
  @override
  _appInvestigation createState() => _appInvestigation();
}

class _appInvestigation extends State<appInvestigation> {
  int _counter = 0;
  BookSqlite bookSqlite = new BookSqlite();
  final TextEditingController _controller = new TextEditingController();
  var SqlAllList;
  //存储热门标签单词块的集合
  List<String> hotList=[
    "汉化",
    "单行本",
    "同人志",
    "Cosplay",
    "CG书集",
    "短篇",
    "日语",
    "韩漫",
  ];
  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  //启动先插入1条数据
  void insertData(String str) async{
    await bookSqlite.openSqlite();
    List alllist= await bookSqlite.queryAll();
    var indx;
    if(alllist==null){
      indx=0;
    }else
      {
        indx=alllist.length;
      }
    await bookSqlite.insert(Book(indx,"历史记录","flutter",0.1,str));
    await SqlBookDate.sharedInstance().OnAllSQLData();
    //await bookSqlite.clear();
    //切记用完就close
    // await bookSqlite.close();
  }



  @override
  Widget build(BuildContext context) {
    FocusNode focusNode2 = new FocusNode();
    return Scaffold(
      appBar: AppBar(title: Text(' '),
      iconTheme: IconThemeData(
        color: Colors.red
      ),
      actions: <Widget>[
       Container(
         width: MediaQuery.of(context).size.width,
         height: 40,
         child:  Stack(children: <Widget>[

           Align(
               alignment: Alignment.lerp(Alignment.center, Alignment.topCenter, 0),
               child: GestureDetector(
                 child: Image.asset('img/download.png'),
                 onTap: (){
                 },
               )
           ),

          Positioned(
            top: 15,
            left: 350,
            child: GestureDetector(
              child: Text('搜索',style: TextStyle(fontWeight: FontWeight.w400,fontSize: 18, color: Colors.red),),
              onTap: (){
                if(_controller.text==''){
                  return;
                }
                insertData(_controller.text);
                AppNavigator.push(context,  PullAndPushTest(_controller.text));
              },
            )
          ),
           Positioned(
             top: 3.5,
             left: 120,
             child:      Container(width: 200,height: 60,
               child: TextField(
                 controller: _controller,
                 decoration: InputDecoration(border: InputBorder.none,
               ),style: TextStyle(color: Colors.white),cursorColor: Colors.white,

               ),
             ),
           ),



         ],),
       ),



      ],
      ),
      body:
      //直接返回流式布局
      raiseFlowLayout(context),
    );
  }

  //创建流式布局方法
  Widget raiseFlowLayout(BuildContext context) {
    //import 'dart:math';用来生成随机颜色
    var random = new Random();
    EdgeInsets edgeInsets = EdgeInsets.all(5);
    //判断历史记录是否为null
    if(SqlBookDate.sharedInstance().SqlAllList==null){
      SqlBookDate.sharedInstance().SqlAllList=[];
    }
    //循环添加
    //记录添加控件之后的宽度
    return MediaQuery.removePadding(
        removeTop: true,
        context: context,
        child:ListView(
          scrollDirection: Axis.vertical,
          children: <Widget>[
            Text(' 历史搜索',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w600),),
            Wrap(
              children: _generateWSList1(SqlBookDate.sharedInstance().SqlAllList.length, random,SqlBookDate.sharedInstance().SqlAllList),
            ),
            SizedBox(height: 20,),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 5,
              color: Colors.black26,
            ),
            //热门标签
            SizedBox(height: 20,),
            Text(' 热门标签',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w600),),
            Wrap(
              children: _generateWSList2(hotList.length, random,hotList),
            )
          ],)
    );


  }

  //生成单个单词块
  Widget _generateWordSquare(Random random,String str) {
    //随机颜色
    var color = Color.fromARGB(random.nextInt(255), random.nextInt(255),
        random.nextInt(255), random.nextInt(255));
    var wp = WordPair.random();
    return new Card(
      color: color,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
      child: Container(
         // color: color,
          height: 35,
          padding: EdgeInsets.fromLTRB(5, 0, 5, 0),
          child: Stack(
            alignment: Alignment.center,
            children: <Widget>[
              Text(
                str,
                style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600),
              ),
            ],
          )
      )
    );
  }

  //生成n个标签块
  List<Widget> _generateWSList2(int n, Random random,List<String> str) {
    var list = new List<Widget>();
    for (int i = 0; i < n; i++) {
      list.add(_generateWordSquare(random,str[i]));
    }
    return list;
  }
  List<Widget> _generateWSList1(int n, Random random,List str) {
    var list = new List<Widget>();
    for (int i = 0; i < n; i++) {
      list.add(_generateWordSquare(random,str[i].publishingHouse));
    }
    return list;
  }

}

class MyFlowDelegate extends FlowDelegate {
  //定义默认边距=0
  var _margin = EdgeInsets.zero;
  //提供构造方法,可以根据构造设定_margin的值
  MyFlowDelegate(this._margin);
  @override
  void paintChildren(FlowPaintingContext context) {
    //绘制单词块的左边距
    var offsetX = _margin.left;
    //绘制单词块的顶边距
    var offsetY = _margin.top;
    //屏幕/父容器宽度
    var winSizeWidth = context.size.width;
    //开始循环绘制，绘制过程中进行offset的变化
    for (int i = 0; i < context.childCount; i++) {
      //当前的宽度
      var w = offsetX + context.getChildSize(i).width + _margin.right;
      //如果当前的宽度大于等于屏幕宽度，那么就需要换行，否则，继续在本行绘制
      if (w < winSizeWidth) {
        //绘制子控件
        context.paintChild(i,
            transform: new Matrix4.translationValues(offsetX, offsetY, 0.0));
        //绘制完后记得对x进行累加
        offsetX = w + _margin.left;
      } else {
        //换行
        //充值左边距
        offsetX = _margin.left;
        //换行之后的y偏移量=上面一个的偏移量+行高+顶部margin+底部margin
        offsetY +=
            context.getChildSize(i).height + _margin.bottom + _margin.top;
        //绘制
        context.paintChild(i,
            transform: new Matrix4.translationValues(offsetX, offsetY, 0.0));
        //绘制完下一行的第一个之后，记得更新offsetX
        offsetX += context.getChildSize(i).width + _margin.right;
      }
    }
  }

  @override
  bool shouldRepaint(FlowDelegate oldDelegate) {
    // 暂时不用
    return null;
  }
}







class FocusTestRoute extends StatefulWidget {
  @override
  _FocusTestRouteState createState() => new _FocusTestRouteState();
}

class _FocusTestRouteState extends State<FocusTestRoute> {
  FocusNode focusNode2 = new FocusNode();
  FocusScopeNode focusScopeNode;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Stack(
        children: <Widget>[
          TextField(
            cursorColor: Colors.red,
            focusNode: focusNode2,//关联focusNode2
            decoration: InputDecoration(
                labelText: "input2"
            ),
            onChanged: (text){
              print(text);
            },
          ),

        ],
      ),
    );
  }

}












