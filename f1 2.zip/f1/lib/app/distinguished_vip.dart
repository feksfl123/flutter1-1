import 'package:flutter/material.dart';


class disvipScene extends StatelessWidget {///vip
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("欢迎来到vip"),
          elevation: 0,
        ),
        body: Center(
            child: Text("欢迎来到vip")
        )
    );
  }
}




class shareScene extends StatelessWidget {///分享得币
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("欢迎来到分享得币"),
          elevation: 0,
        ),
        body: Center(
            child: Text("欢迎来到分享得币")
        )
    );
  }
}




class newsScene extends StatelessWidget {///消息中心
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("欢迎来到消息中心"),
          elevation: 0,
        ),
        body: Center(
            child: Text("欢迎来到消息中心")
        )
    );
  }
}


class PostScene extends StatelessWidget {///我的贴子
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("欢迎来到我的贴子"),
          elevation: 0,
        ),
        body: Center(
            child: Text("欢迎来到我的贴子")
        )
    );
  }
}
