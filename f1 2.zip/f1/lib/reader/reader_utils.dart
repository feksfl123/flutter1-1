class ReaderUtils {
  static double topOffset = 37;
  static double bottomOffset = 37;
}
