
import 'package:flutter/material.dart';
import 'package:flutter_simple_video_player/flutter_simple_video_player.dart';
import 'dart:ui';
import 'package:screen/screen.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'theaterinfo.dart';
import 'anime_scene.dart';

class Animemessage extends StatefulWidget {
  Animemessage({Key key,@required this.spmap}) : super(key: key);
  final Map spmap;
  SimpleMupage createState() => SimpleMupage();
}

class SimpleMupage extends State<Animemessage> {
  @override
  List MupageList;//片源
  int MUpageCount=0;//片级
  factory SimpleMupage() =>_getInstance();
  static SimpleMupage _instance;
  static SimpleMupage _getInstance() {
      _instance = new SimpleMupage._internal();
    return _instance;
  }
  void UpdateState(){
   setState(() {

   });


  }
  SimpleMupage._internal() {
    // 初始化
  }
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(40.0),
          child: AppBar(title: Text('影视详情'),
          backgroundColor: Colors.black,
          )
      ),

        body: Container(
          width: double.infinity,
          height: double.infinity,
          child: ListView(
            physics: NeverScrollableScrollPhysics(),
            children: <Widget>[
              Container(
                height: 230,
                child: SimpleViewPlayer(widget.spmap['source'], isFullScreen: false,),
              ),
              FilmtelevDetails(spMapDate:widget.spmap,MupagePaList:MupageList),
            ],
          )
        )
    );
  }

  void setUpdateMupage(int MpIdx){
    MUpageCount=MpIdx;
  }
  int getUpdateMupage(){
    return MUpageCount;
  }


}

class FilmtelevDetails extends StatefulWidget {
  FilmtelevDetails({Key key,@required this.spMapDate,@required this.MupagePaList}) : super(key: key);
  final Map spMapDate;
  final List MupagePaList;
  _FilmtelevDetails createState() => _FilmtelevDetails();
}

//影视详情类
class _FilmtelevDetails extends State<FilmtelevDetails>{
  Color _DefaultBcolor= Colors.cyan;
  int volumefilm=0;
  @override
  Widget build(BuildContext context){

    return Container(
      height: MediaQuery.of(context).size.height/1.55,
      color: Colors.white,
      child: ListView(
        children: <Widget>[
          Column(
            children: <Widget>[
              Container(
                width:  double.infinity,
                height: 65,
                color: Colors.white,
                child: Stack(
                  children: <Widget>[
                    Positioned(
                      top: 0.0,
                      left: 20.0,
                      child: Text(widget.spMapDate['title'], style: TextStyle(
                          color: Colors.black, fontSize: 21.0),),
                    ),
                    Positioned(
                      top: 38.0,
                      left: 60.0,
                      child: Text(widget.spMapDate['Popularity'], style: TextStyle(
                          color: Colors.black45, fontSize: 16.0),),
                    ),
                    Positioned(
                      top: 35.0,
                      left: 20.0,
                      child: Text('热度:', style: TextStyle(
                          color: Colors.black45, fontSize: 16.0),),
                    ),

                    Positioned(
                      top: 35.0,
                      left: 120.0,
                      child: Text('点赞:', style: TextStyle(
                          color: Colors.black45, fontSize: 16.0),),
                    ),

                    Positioned(
                      top: 38.0,
                      left: 160.0,
                      child: Text(widget.spMapDate['awesome'], style: TextStyle(
                          color: Colors.black45, fontSize: 16.0),),
                    ),

                    Positioned(
                      top: 10.0,
                      left: MediaQuery.of(context).size.width/1.22,
                      child: Text('简介 >', style: TextStyle(
                          color: Colors.black45, fontSize: 17.0),),
                    ),

                    Positioned(
                        top: 62.0,
                        left: 3.0,
                        child: Container(
                          height: 1,
                          width: MediaQuery.of(context).size.width,
                          color: Colors.black12,
                        )
                    ),
                  ],
                ),
              ),
              ///普通
              Container(
                color: Colors.white,
                height: 85,
                child: Stack(
                  children: <Widget>[
                    Positioned(
                      left: 50,
                      top: 15,
                      child: Icon(Icons.expand_more),
                    ),

                    ExpansionTile(
                        title: Text('普通',style: TextStyle(fontSize: 16,color: Colors.black45,fontWeight:
                        FontWeight.w600
                        ),),
                        backgroundColor: Colors.white,
                        initiallyExpanded: false, // 是否默认展开
                        children: <Widget>[
                          Stack(children: <Widget>[
                            Align(
                              alignment: Alignment.lerp(Alignment.topLeft, Alignment.topRight, 0.034),
                              child: Container(
                                  width: 60,
                                  height: 25,
                                  child:      SizedBox.expand(
                                      child: FlatButton(
                                        onPressed: (){},
                                        child: Text('普通',style: TextStyle(color: Colors.white,fontSize: 14,
                                        ),),
                                        color:Colors.orange,
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(Radius.circular(5))
                                        ),
                                      )
                                  )
                              )
                            )
                          ],)

                        ]
                    ),
                    Positioned(
                      left: 100,
                      top: 20,
                      child: Text('问题反馈',style: TextStyle(fontSize: 15,color: Colors.black45,fontWeight:
                      FontWeight.w600
                      ),),
                    ),
                    ///收藏
                    Positioned(
                      left: MediaQuery.of(context).size.width/1.8,
                      top: 20,
                      child:  Icon(Icons.favorite_border),
                    ),
                    Positioned(
                      left: MediaQuery.of(context).size.width/1.8,
                      top: 45,
                      child:  Text('收藏',style: TextStyle(fontSize: 13,color: Colors.black45,fontWeight:
                      FontWeight.w600
                      ),),
                    ),

                    ///缓存
                    Positioned(
                      left: MediaQuery.of(context).size.width/1.4,
                      top: 20,
                      child:  Icon(Icons.get_app,),
                    ),
                    Positioned(
                      left: MediaQuery.of(context).size.width/1.4,
                      top: 45,
                      child:  Text('缓存',style: TextStyle(fontSize: 13,color: Colors.black45,fontWeight:
                      FontWeight.w600
                      ),),
                    ),


                    ///缓存
                    Positioned(
                      left: MediaQuery.of(context).size.width/1.15,
                      top: 20,
                      child:  Container(
                        width: 50,
                        height: 50,
                        color: Colors.white,
                      )
                    ),
                    Positioned(
                      left: MediaQuery.of(context).size.width/1.15,
                      top: 20,
                      child:  Icon(Icons.get_app,),
                    ),
                    Positioned(
                      left: MediaQuery.of(context).size.width/1.15,
                      top: 45,
                      child:  Text('缓存',style: TextStyle(fontSize: 13,color: Colors.black45,fontWeight:
                      FontWeight.w600
                      ),),
                    ),






                  ],
                ),

              ),
              Container(
                alignment: Alignment.topLeft,
                width: MediaQuery.of(context).size.width,
                height: 3,
                color: Colors.black12,
              ),
              SizedBox(
                height: 5,
              ),

              ///剧集
               Stack(children: <Widget>[
                 Container(
                   alignment: Alignment.topLeft,
                   child:  Text('  连载中', style: TextStyle(
                       color: Colors.black, fontSize: 18.0),),
                 ),

                  Positioned(
                    left: 70,
                    top: 4,
                      child:  Text('  更新至12话', style: TextStyle(
                          color: Colors.black45, fontSize: 15.0),),
                  ),

                 Positioned(
                     left: MediaQuery.of(context).size.width/1.10,
                     top: -8,
                     child: Container(
                       child: IconButton(
                         icon: Icon(Icons.fiber_manual_record),
                         color: Colors.blue,
                         onPressed: () {},
                       ),
                     )
                 ),

                 Positioned(
                   left: MediaQuery.of(context).size.width/1.10,
                   top: -8,
                   child: Container(
                     child: IconButton(
                       icon: Icon(Icons.navigate_next),
                       color: Colors.white,
                       onPressed: () {},
                     ),
                   )
                 ),

                 Positioned(
                   left: MediaQuery.of(context).size.width/1.16,
                   top: 4,
                   child:  Text('更多', style: TextStyle(
                       color: Colors.blue, fontSize: 16.0),),
                 )

               ],),

                Container(
                  height: 5,
                ),
                Container(
                  width: 500,
                  height: 60,
                  child:   ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 10,
                    itemBuilder: (context,index){
                      int tmepIdx=index+1;
                      if(index==volumefilm)
                      {
                        _DefaultBcolor= Colors.purple;
                      }
                      else{
                        _DefaultBcolor= Colors.cyan;
                      }
                      return Center(
                        child: Card(
                            color: _DefaultBcolor,
                            child: Container(
                                alignment: Alignment.center,
                                width: 80,
                                height: 50,
                                child: GestureDetector(
                                  child: Text('第$tmepIdx集',style: TextStyle(fontSize: 17.0,color: Colors.white),),
                                  //选择播放的集数
                                  onTap: (){
                                    pleViewPlayerState.instance.controller.pause();
                                    SimpleMupage._instance.setUpdateMupage(1);
                                    SimpleMupage._instance.UpdateState();
                                    pleViewPlayerState.instance.yoered(widget.MupagePaList[index]);
                                    volumefilm=index;
                                    setState(() {

                                    });

                                  },

                                )
                            )
                        ),
                      );

                    }
                  ),
                ),
              SizedBox(
                height: 10,
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                child: Row(
                  children: <Widget>[
                    Container(
                        width: MediaQuery.of(context).size.width/4,
                        height: 120,
                        child: Stack(
                          children: <Widget>[
                            Positioned(
                              left: 18,
                              child:GestureDetector(
                                child: Image.asset('img/praise1.png',
                                width: 70,height: 70,
                                ),

                                onTap: (){},
                              )
                            ),
                            Positioned(
                              left:15,
                              bottom: 26,
                              child: Text('好看的一匹'),
                            ),
                            Positioned(
                              left:35,
                              bottom: 5,
                              child: Text('2951'),
                            )
                          ],
                        )

                    ),
                    Container(
                        width: MediaQuery.of(context).size.width/4,
                        height: 120,
                        child: Stack(
                          children: <Widget>[
                            Positioned(
                              left: 15,
                              child:GestureDetector(
                                child: Image.asset('img/praise2.png',width: 70,height: 70,),

                                onTap: (){},
                              )
                            ),
                            Positioned(
                              left: 35,
                              bottom: 26,
                              child: Text('必须赞'),
                            ),
                            Positioned(
                              left:37,
                              bottom: 5,
                              child: Text('2686'),
                            )
                          ],
                        )

                    ),
                    Container(
                        width: MediaQuery.of(context).size.width/4,
                        height: 120,
                        child: Stack(
                          children: <Widget>[
                            Positioned(
                              left: 15,
                              child:GestureDetector(
                                child: Image.asset('img/praise3.png',width: 70,height: 70,),

                                onTap: (){},
                              )
                            ),
                            Positioned(
                              left: 30,
                              bottom: 26,
                              child: Text('神马鬼'),
                            ),
                            Positioned(
                              left:35,
                              bottom: 5,
                              child: Text('250'),
                            )
                          ],
                        )

                    ),
                    Container(
                        width: MediaQuery.of(context).size.width/4,
                        height: 120,
                        child: Stack(
                          children: <Widget>[
                            Positioned(
                              left: 15,
                              child:GestureDetector(
                                child: Image.asset('img/praise4.png',width: 70,height: 70,),

                                onTap: (){},
                              )
                            ),
                            Positioned(
                              left: 25,
                              bottom: 26,
                              child: Text('不好看'),
                            ),
                            Positioned(
                              left:35,
                              bottom: 5,
                              child: Text('141'),
                            )
                          ],
                        )

                    ),

                  ],
                )
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                child: Row(
                  children: <Widget>[
                    Image.asset('img/icon1.png',width: 25,height: 25,),
                    SizedBox(
                      width: 5,
                    ),
                    Text('猜你喜欢', style: TextStyle(
                        color: Colors.black, fontSize: 16.1),),
                  ],
                ),
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          TheaterInfo(ComicHomeState.sharedInstance().theaterList,false)///猜你喜欢
        ],
      ),
    );


  }
}