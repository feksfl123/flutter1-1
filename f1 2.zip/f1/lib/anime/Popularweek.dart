
import 'package:flutter/material.dart';
import 'package:tianyue/public.dart';
import 'package:tianyue/comic_home/comic_block_item_view.dart';
import 'package:tianyue/comic_home/comic_block_header_view.dart';

///最近更新
class Popularweek extends StatelessWidget {
  final Map blockList;

  Popularweek(this.blockList);

  @override
  Widget build(BuildContext context) {
    if (blockList == null || blockList.length == 0) {
      return Container();
    }

    return Container(
        width: Screen.width,
        height: 230,
        child: Stack(
          children: <Widget>[
            ComicBlockHeaderView(Constant.recommendEveryDay),

            Container(
              padding: EdgeInsets.fromLTRB(0,40,0,0),
              child:ListView(
                physics: NeverScrollableScrollPhysics(),
                scrollDirection: Axis.horizontal,
                children: <Widget>[
                  SizedBox(height: 5),
                  SizedBox(height: 5),
                  Container(
                    padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                    child: Popularweekda(blockList, TYColor.white),
                  ),
                ],
              ),
            ),
            ///人气等级
            Container(
              padding: EdgeInsets.fromLTRB(0, 35, 0, 0),

              child: Icon(Icons.bookmark,color: Colors.pink,size: 30,),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(9, 37, 0, 0),
              child: Text('1',style: TextStyle(color:Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 18),)
            ),
          ],
        )
    );
  }
}




class Popularweekda extends StatelessWidget {
  final Map comicItem;
  final Color bgColor;

  Popularweekda(this.comicItem, this.bgColor);

  @override
  Widget build(BuildContext context) {
    var width = (Screen.width - 15 * 2 - 15 * 2) / 2.20;
    return GestureDetector(
      onTap: () {
        AppNavigator.pushAnimeMessage(context, comicItem);
      },
      child: Container(
        //color: bgColor,
        width: Screen.width,
        child: Stack(
          children: <Widget>[
            NovelCoverImage(comicItem['cover'],
                width: width+10, height: width / 1.25),
            Container(
              padding: EdgeInsets.fromLTRB(185,15,0,0),
              child:   Text(
                comicItem['title'],
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    decoration: TextDecoration.none),
                maxLines: 1,
              ),
            ),

            Container(
              padding: EdgeInsets.fromLTRB(185,90,0,0),
              child:  Text(
                comicItem['description'],
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 12,
                    color: TYColor.gray,
                    decoration: TextDecoration.none),
                maxLines: 1,
              ),
            ),
            ///火度
            Container(
              padding: EdgeInsets.fromLTRB(185,45,0,0),
              child: Icon(Icons.whatshot,color: Colors.black,size: 18),
            ),

            Container(
              padding: EdgeInsets.fromLTRB(205,45,0,0),
              child:  Text(
                comicItem['Popularity'],
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 12,
                    color: TYColor.gray,
                    decoration: TextDecoration.none),
                maxLines: 1,
              ),
            ),

            ///赞
            Container(
              padding: EdgeInsets.fromLTRB(260,45,0,0),
              child: Icon(Icons.thumb_up,color: Colors.black,size: 15,),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(280,45,0,0),
              child:  Text(
                comicItem['awesome'],
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 12,
                    color: TYColor.gray,
                    decoration: TextDecoration.none),
                maxLines: 1,
              ),
            ),




            SizedBox(height: 4),
          ],
        ),
      ),
    );
  }
}




