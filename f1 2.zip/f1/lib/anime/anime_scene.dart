import 'dart:async';

import 'package:flutter/material.dart';
import 'package:tianyue/comic_home/comic_banner.dart';
import 'package:tianyue/comic_home/comic_block_view.dart';
import 'package:tianyue/comic_home/comic_recommend_everyday_view.dart';
import 'package:tianyue/comic_home/comic_update_today_view.dart';
import 'package:tianyue/public.dart';
import 'package:tianyue/widget/loading_indicator.dart';
import 'Typebtn.dart';
import 'package:tianyue/anime/Recentlyupdated.dart';
import 'Popularweek.dart';
import 'theaterinfo.dart';

class AnimeScene extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => ComicHomeState();
}

class ComicHomeState extends State<AnimeScene> with SingleTickerProviderStateMixin{
  Comic comic;

  /// banner
  List<String> banner = [];

  /// 最近更新
  List<Map> blockList = [];

  /// 剧场
  List<Map> theaterList = [];

  /// 本周人气
  Map popularList;

  /// 今日我更新
  List<UpdateToday> updateTodayList = [];

  ScrollController scrollController = ScrollController();
  double navAlpha = 0;

  /// 是否请求数据完毕
  bool isDataReady = false;

  PageState pageState = PageState.Loading;

  ///顶部导航
  TabController tabController;

  // 单例公开访问点
  factory ComicHomeState() =>sharedInstance();

  // 静态私有成员，没有初始化
  static ComicHomeState _instance = ComicHomeState._();

  // 私有构造函数
  ComicHomeState._() {
    // 具体初始化代码
  }

  // 静态、同步、私有访问点
  static ComicHomeState sharedInstance() {
    return _instance;
  }

  @override
  void initState() {
    super.initState();

    tabController= new TabController(length:7, vsync: this);

    fetchData();
    scrollController.addListener(() {
      var offset = scrollController.offset;
      if (offset < 0) {
        if (navAlpha != 0) {
          setState(() {
            navAlpha = 0;
          });
        }
      } else if (offset < 50) {
        setState(() {
          navAlpha = 1 - (50 - offset) / 50;
        });
      } else if (navAlpha != 1) {
        setState(() {
          navAlpha = 1;
        });
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    scrollController.dispose();
  }

  Future<void> fetchData() async {
    try {

      await Future.delayed(Duration(milliseconds: 2000), () {
        pageState = PageState.Content;
      });

      var responseJson = await Request.get(url: 'home_comic');
      banner.clear();
      banner.add("http://pic.netbian.com/uploads/allimg/191215/215809-15764182898a9c.jpg");
      blockList.clear();
      theaterList.clear();
      List<Map> spMap=[
        {
          'cover':'http://ws3.sinaimg.cn/large/007iocwWly1fyqwh9bttnj30rs0p0dii.jpg',
          'title':'双枪血魔',
          'description':'怪我咖',
          'source':'https://youku.cdn-tudou.com/20180422/5344_5b26a602/index.m3u8',
          'Popularity':'575',
          'awesome':'45455',
        },
        {
          'cover':'http://ws3.sinaimg.cn/mw1024/007iocwWly1fypicpor9hj30lw0fyk2e.jpg',
          'title':'暴走护士',
          'description':'爱意满满',
          'source':'https://youku.cdn-tudou.com/20180422/5344_5b26a602/index.m3u8',
          'Popularity':'76752',
          'awesome':'7867',
        },
        {
          'cover':'http://ws3.sinaimg.cn/mw1024/007iocwWly1fyqwhcgxdkj30m80r9k2a.jpg',
          'title':'爱杀宝贝',
          'description':'宝贝我来了',
          'source':'https://youku.cdn-tudou.com/20180422/5344_5b26a602/index.m3u8',
          'Popularity':'12212',
          'awesome':'4332',
        },
        {
          'cover':'http://ws3.sinaimg.cn/mw1024/007iocwWly1fyqwh85v2sj30go0k0jtc.jpg',
          'title':'小李飞刀',
          'description':'刀刀必杀',
          'source':'https://youku.cdn-tudou.com/20180422/5344_5b26a602/index.m3u8',
          'Popularity':'76634',
          'awesome':'54332',
        },
      ];


      blockList.add(spMap[0]);
      blockList.add(spMap[1]);
      blockList.add(spMap[2]);
      blockList.add(spMap[3]);


      List<Map> theaterMap=[
        {
          'cover':'https://img2.woyaogexing.com/2019/12/15/89d6a26990b5461aac725b651a6ec61d.jpeg',
          'title':'冰雪大作战',
          'description':'怪我咖',
          'source':'https://youku.cdn-tudou.com/20180422/5344_5b26a602/index.m3u8',
          'Popularity':'9876',
          'awesome':'8775',
        },
        {
          'cover':'https://img2.woyaogexing.com/2019/12/14/2e28160096d146abac8b41f8ce1877f5.jpeg',
          'title':'回忆中的玛妮',
          'description':'爱意满满',
          'source':'https://youku.cdn-tudou.com/20180422/5344_5b26a602/index.m3u8',
          'Popularity':'7056',
          'awesome':'543',
        },
        {
          'cover':'https://img2.woyaogexing.com/2019/12/06/2b5c8f64824e46e7842a732ab640552b!1242x9999.jpeg',
          'title':'生化危机: 复仇',
          'description':'宝贝我来了',
          'source':'https://youku.cdn-tudou.com/20180422/5344_5b26a602/index.m3u8',
          'Popularity':'212',
          'awesome':'3221',
        },
        {
          'cover':'https://img2.woyaogexing.com/2019/11/14/2db669dc629c4523972dc09be640d1e3!400x400.jpeg',
          'title':'时钟机关之星',
          'description':'刀刀必杀',
          'source':'https://youku.cdn-tudou.com/20180422/5344_5b26a602/index.m3u8',
          'Popularity':'10032',
          'awesome':'7543',
        },
      ];
      theaterList.add(theaterMap[0]);
      theaterList.add(theaterMap[1]);
      theaterList.add(theaterMap[2]);
      theaterList.add(theaterMap[3]);


      popularList={
        'cover':'https://img2.woyaogexing.com/2019/08/13/db0a33a79bd746dea48a3c5ebc6b02be!380x240.jpeg',
        'title':'海绵宝宝',
        'description':'校园',
        'Popularity':'176820',
        'awesome':'38999',
        'source':'https://youku.cdn-tudou.com/20180422/5344_5b26a602/index.m3u8',
      };

      setState(() {
        isDataReady = true;
      });
    } catch (e) {
      print(e.toString());
      Toast.show(e.toString());
    }
  }

  /// 失败重试
  _retry() {
    pageState = PageState.Loading;
    setState(() {});
    fetchData();
  }

  Widget buildActions(Color iconColor) {
    return Column(children: <Widget>[

      Container(
        padding: EdgeInsets.fromLTRB(340, 50,0, 0),
        child: Container(
          height: 30,
          width: 30,
          child: Image.asset('img/actionbar_search.png',
              width: 30,height: 30,fit: BoxFit.fill,
              color: iconColor),
        ),
      )
    ]);
  }

  ///推荐
  Widget buildModule(BuildContext context, int index) {
    Widget widget;
    switch (index) {
      case 0:
        widget = ComicBanner(banner);
        break;
      case 1:
        widget = TypeBtnScene();
        break;
      case 2:
        widget = RecentlyupdatedView(blockList);///最近更新
        break;
      case 3:
        widget = Popularweek(popularList);///本周人气
        break;
      case 4:
        widget = TheaterInfo(theaterList,true);///剧场/OVA
        break;
    }
    return widget;
  }

  @override
  Widget build(BuildContext context) {
    if (blockList == null || blockList.length == 0) {
      return LoadingIndicator(
        pageState,
        retry: _retry,
      );
    }
    return Scaffold(
      backgroundColor: TYColor.comicBg,
      body: Stack(children: [
        RefreshIndicator(
          onRefresh: fetchData,
          color: TYColor.primary,
          child: MediaQuery.removePadding(
            removeTop: true,
            context: context,
            child: ListView.builder(
              scrollDirection: Axis.vertical,
              controller: scrollController,
              itemCount: 5,
              itemBuilder: (BuildContext context, int index) {
                return buildModule(context, index);
              },
            ),
          ),
        ),
        buildActions(Colors.lightBlue),

      ]),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
