//import 'dart:html';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tianyue/me/EventChannelScene.dart';
import 'package:tianyue/me/PaintWidgetScene.dart';
import 'package:tianyue/me/ScrollDemoScene.dart';
import 'package:tianyue/me/map_scene.dart';
import 'package:tianyue/public.dart';
import 'package:tianyue/stream/BlocScene.dart';
import 'package:tianyue/stream/StreamCounterScene.dart';

import 'package:tianyue/app/distinguished_vip.dart';
import 'animeLeaderboard.dart';

class TypeBtnScene extends StatelessWidget {
  //分类按钮
  List<String> TypeButList = ['img/animelist1.png',
    'img/animelist2.png','img/animelist3.png','img/animelist4.png'];
  // 单例公开访问点
  factory TypeBtnScene() =>sharedInstance();

  // 静态私有成员，没有初始化
  static TypeBtnScene _instance = TypeBtnScene._();

  // 私有构造函数
  TypeBtnScene._() {
    // 具体初始化代码
  }

  // 静态、同步、私有访问点
  static TypeBtnScene sharedInstance() {
    return _instance;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(0, 2, 0, 0),
      width: Screen.width,
      height: Screen.height/11,
      color: Colors.lightBlueAccent,
      child: Row(
        children: <Widget>[

          Align(
              child: GestureDetector(
                child: Container(
                  width: MediaQuery.of(context).size.width/4,
                  height: 100,
                  child: Column(
                    children: <Widget>[
                      Image.asset(TypeButList[0]),
                      Text('更新')
                    ],
                  ),
                ),
                onTap: (){
                  AppNavigator.push(context, animeLeaderboard());
                },
              )
          ),

          Align(
              child: GestureDetector(
                child: Container(
                  width: MediaQuery.of(context).size.width/4,
                  height: 70,
                  child: Column(
                    children: <Widget>[
                      Image.asset(TypeButList[1]),
                      Text('完结')
                    ],
                  ),
                ),
                onTap: (){
                  AppNavigator.push(context, animeLeaderboard());
                },
              )
          ),

          Align(
              child: GestureDetector(
                child: Container(
                  width: MediaQuery.of(context).size.width/4,
                  height: 70,
                  child: Column(
                    children: <Widget>[
                      Image.asset(TypeButList[2]),
                      Text('榜单')
                    ],
                  ),
                ),
                onTap: (){
                  AppNavigator.push(context, animeLeaderboard());
                },
              )
          ),

          Align(
              child: GestureDetector(
                child: Container(
                  width: MediaQuery.of(context).size.width/4,
                  height: 70,
                  child: Column(
                    children: <Widget>[
                      Image.asset(TypeButList[3]),
                      Text('分类')
                    ],
                  ),
                ),
                onTap: (){
                  AppNavigator.push(context, animeLeaderboard());
                },
              )
          ),



        ],
      ),
    );
}
}
