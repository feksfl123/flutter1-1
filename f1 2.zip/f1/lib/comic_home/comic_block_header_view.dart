import 'package:flutter/material.dart';
import 'package:tianyue/public.dart';

class ComicBlockHeaderView extends StatelessWidget {
  final String titleName;

  ComicBlockHeaderView(this.titleName);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: buildHeader(context),
    );
  }

  Widget buildHeader(BuildContext context) {
    Widget widget;
    var width = Screen.width;
    switch (titleName) {
      case Constant.comicBlock:
        widget = Container(
          width: Screen.width,
          height: 50,
          child: Row(
            children: <Widget>[
              SizedBox(width: 10,),
              Icon(Icons.access_time,color: Colors.blueAccent,),
              SizedBox(width: 5,),
              Text('最近更新',style: TextStyle(fontWeight: FontWeight.w600,
                 fontSize: 16)),

              SizedBox(width: MediaQuery.of(context).size.width/1.71,),
              Text('更多',style: TextStyle(fontWeight: FontWeight.w600,color: Colors.blueAccent)),
              Icon(Icons.keyboard_arrow_right,color: Colors.blueAccent,),

            ],
          )
        );
        break;
      case Constant.recommendEveryDay:
        widget = Container(
            width: Screen.width,
            height: 50,
            child: Row(
              children: <Widget>[
                SizedBox(width: 10,),
                Icon(Icons.forum,color: Colors.blueAccent,),
                SizedBox(width: 5,),
                Text('本周人气',style: TextStyle(fontWeight: FontWeight.w600,
                    fontSize: 16)),

                SizedBox(width: MediaQuery.of(context).size.width/1.71,),
                Text('更多',style: TextStyle(fontWeight: FontWeight.w600,color: Colors.blueAccent)),
                Icon(Icons.keyboard_arrow_right,color: Colors.blueAccent,),

              ],
            )
        );
        break;
      case Constant.updateToday:
        widget = Container(
            width: Screen.width,
            height: 50,
            child: Row(
              children: <Widget>[
                SizedBox(width: 10,),
                Icon(Icons.featured_video,color: Colors.blueAccent,),
                SizedBox(width: 5,),
                Text('剧场/OVA',style: TextStyle(fontWeight: FontWeight.w600,
                    fontSize: 16)),

                SizedBox(width: MediaQuery.of(context).size.width/1.77,),
                Text('更多',style: TextStyle(fontWeight: FontWeight.w600,color: Colors.blueAccent)),
                Icon(Icons.keyboard_arrow_right,color: Colors.blueAccent,),

              ],
            )
        );
        break;
    }
    return widget;
  }
}
