//import 'dart:html';//不屏蔽会报错

import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'package:tianyue/public.dart';

class MeHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var user = UserManager.currentUser;

    return GestureDetector(
      onTap: () {
        if (UserManager.instance.isLogin) {
          AppNavigator.pushWeb(context, 'https://github.com/ZDfordream/TianYueFlutter', 'Github');
        } else {
          AppNavigator.pushLogin(context);
        }
      },
      child: Container(
        height: Screen.height/4.5,
        child: Stack(
          children: <Widget>[
          Container(
            height: Screen.height/8,
            decoration: BoxDecoration(

              gradient: new LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.topRight,
                  colors: [
                    Colors.redAccent,
                    Colors.pinkAccent,
                  ]),
            ),
            padding: EdgeInsets.fromLTRB(0.00, 6.00, 0.00, 6.00),
            width: MediaQuery.of(context).size.width,
          ),
            Container(
                //color: TYColor.white,
                height: Screen.height/4,
                padding: EdgeInsets.fromLTRB(15, 30, 15, 15),
                child: Card(
                  elevation: 5.0,
                  child: Align(
                    child: Row(
                      children: <Widget>[
                        SizedBox(width: 115),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                user != null ? user.nickname : '立即登录>',
                                style: TextStyle(fontSize: 18),
                              ),
                              Text(
                                '手机号登陆赠送500污妖币',
                                style: TextStyle(fontSize: 14),
                              ),
                              SizedBox(height: 40),

                            ],
                          ),
                        )
                      ],
                    ),
                  )

                )
            ),

            Positioned(
              top: 35,
              right: 25,
              child: IconButton(
                icon: Icon(Icons.settings),
                color: Colors.blue,
                onPressed: () {},
              ),
            ),

            Positioned(
              left: 30,
              top: 15,
              child: Container(
                height: 75,
                width: 75,
                child: CircleAvatar(
                  backgroundImage: user?.avatarUrl != null ? CachedNetworkImageProvider(user.avatarUrl) : AssetImage('img/placeholder_avatar.png'),
                ),
              ),
            ),

            Positioned(
              top: MediaQuery.of(context).size.width/8,
              left: 100,
              child: buildItems(),
            ),
            Positioned(
              top: MediaQuery.of(context).size.width/4.5,
              left: 140,
              child: IconButton(
                icon: Icon(Icons.verified_user),
                color: Colors.blue,
                onPressed: () {},
              ),
            ),
          ],
        )
      ),
    );
  }

  Widget buildItems() {
    var user = UserManager.currentUser;

    return Stack(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            buildItem(user != null ? user.coupon.toString() : '0', '我的等级'),
            SizedBox(width: 100,),
            buildItem(user != null ? user.wealth.toStringAsFixed(1) : '0.0',
                ' 我的污妖币'),

            // buildItem(user != null ? user.monthlyTicket.toString() : '0', '月票'),
            Container(),
          ],
        ),

      ],
    );
  }

  Widget buildItem(String title, String subtitle) {
    return Stack(
      children: <Widget>[
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.fromLTRB(18, 35, 0, 5),
              child: Text(
                title,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold,),
              ),
            ),
            Text(
              subtitle,
              style: TextStyle(fontSize: 12, color: TYColor.gray),
            ),
          ],
        ),

      ],
    );
  }
}
