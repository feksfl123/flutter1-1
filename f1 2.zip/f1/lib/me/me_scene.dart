//import 'dart:html';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tianyue/me/EventChannelScene.dart';
import 'package:tianyue/me/PaintWidgetScene.dart';
import 'package:tianyue/me/ScrollDemoScene.dart';
import 'package:tianyue/me/map_scene.dart';
import 'package:tianyue/public.dart';
import 'package:tianyue/stream/BlocScene.dart';
import 'package:tianyue/stream/StreamCounterScene.dart';

import 'me_cell.dart';
import 'me_header.dart';
import 'setting_scene.dart';
import 'package:tianyue/app/distinguished_vip.dart';

class MeScene extends StatelessWidget {

  List<String> personalList=['img/personal1.png','img/personal2.png','img/personal3.png','img/personal4.png'];
  // 单例公开访问点
  factory MeScene() =>sharedInstance();

  // 静态私有成员，没有初始化
  static MeScene _instance = MeScene._();

  // 私有构造函数
  MeScene._() {
    // 具体初始化代码
  }

  // 静态、同步、私有访问点
  static MeScene sharedInstance() {
    return _instance;
  }
  Widget buildCells(BuildContext context) {
    Screen.updateStatusBarStyle(SystemUiOverlayStyle.dark);
    return Container(
      child: Column(
        children: <Widget>[
          MeCell(
            title: '我的书架',
            iconName: 'img/me_wallet.png',
            onPressed: () {
              AppNavigator.push(context, bookshelfScene());
            },
          ),
          MeCell(
            title: '购买记录',
            iconName: 'img/me_record.png',
            onPressed: () {
            AppNavigator.push(context, recordScene());

             },
          ),
          MeCell(
            title: '代理赚钱',
            iconName: 'img/me_buy.png',
            onPressed: () {
              AppNavigator.push(context, proxyScene());
            },
          ),
          MeCell(
            title: '加群开车',
            iconName: 'img/me_vip.png',
            onPressed: () {
              AppNavigator.push(context, plusgroupScene());
            },
          ),
          MeCell(
            title: '帮助',
            iconName: 'img/me_coupon.png',
            onPressed: () {
              AppNavigator.push(context, helpScene());
            },
          ),
          MeCell(
            title: '兑换码',
            iconName: 'img/me_favorite.png',
            onPressed: () {
              AppNavigator.push(context, exchangeScene());
            },
          ),
        ],
      ),
    );
  }

  Widget buildbackground(BuildContext context) {
    Screen.updateStatusBarStyle(SystemUiOverlayStyle.dark);
    return Container(
      height: 60,
      decoration: BoxDecoration(

        gradient: new LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.topRight,
            colors: [
              Colors.redAccent,
              Colors.pinkAccent,
            ]),
      ),
      padding: EdgeInsets.fromLTRB(0.00, 6.00, 0.00, 6.00),
      width: MediaQuery.of(context).size.width,
    );
  }

  Widget buildImportant(BuildContext context) {
    Screen.updateStatusBarStyle(SystemUiOverlayStyle.dark);
    return Container(
      child: Stack(
        children: <Widget>[
          
          Align(
            alignment: Alignment.lerp(Alignment.topLeft, Alignment.topRight, 0.05),
            child: GestureDetector(
              child: Container(
                width: 100,
                height: 70,
                child: Column(
                  children: <Widget>[
                    Image.asset(personalList[3]),
                    Text('尊享VIP')
                  ],
                ),
              ),
              onTap: (){
                AppNavigator.push(context, disvipScene());
              },
            )
          ),

          Align(
              alignment: Alignment.lerp(Alignment.topLeft, Alignment.topRight, 0.35),
              child: GestureDetector(
                child: Container(
                  width: 100,
                  height: 70,
                  child: Column(
                    children: <Widget>[
                      Image.asset(personalList[0]),
                      Text('分享赚币')
                    ],
                  ),
                ),
                onTap: (){
                  AppNavigator.push(context, shareScene());
                },
              )
          ),

          Align(
              alignment: Alignment.lerp(Alignment.topLeft, Alignment.topRight, 0.65),
              child: GestureDetector(
                child: Container(
                  width: 100,
                  height: 70,
                  child: Column(
                    children: <Widget>[
                      Image.asset(personalList[1]),
                      Text('消息中心')
                    ],
                  ),
                ),
                onTap: (){
                  AppNavigator.push(context, newsScene());
                },
              )
          ),

          Align(
              alignment: Alignment.lerp(Alignment.topLeft, Alignment.topRight, 0.95),
              child: GestureDetector(
                child: Container(
                  width: 100,
                  height: 70,
                  child: Column(
                    children: <Widget>[
                      Image.asset(personalList[2]),
                      Text('我的贴子')
                    ],
                  ),
                ),
                onTap: (){
                  AppNavigator.push(context, PostScene());
                },
              )
          ),



        ],
      ),
    );
  }


  Future<void> fetchData() async {
//    try {
//
//      await Future.delayed(Duration(milliseconds: 2000), () {
//        pageState = PageState.Content;
//      });
//
//      var responseJson = await Request.get(url: 'home_comic');
//      banner.clear();
//      responseJson["banner"].forEach((data) {
//        banner.add(data);
//      });
//      blockList.clear();
//      responseJson["blockList"].forEach((data) {
//        blockList.add(ComicBlock.fromJson(data));
//      });
//      updateTodayList.clear();
//      responseJson["updateTodayList"].forEach((data) {
//        updateTodayList.add(UpdateToday.fromJson(data));
//      });
//      recommendEveryDay =
//          RecommendEveryDay.fromJson(responseJson["recommendEveryDay"]);
//      setState(() {
//        isDataReady = true;
//      });
//    } catch (e) {
//      print(e.toString());
//      Toast.show(e.toString());
//    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
//      appBar: PreferredSize(
//
//        preferredSize: Size(Screen.width, 0),
//      ),
      body: Container(
        color: Colors.white,
        child: Stack(
          //physics: BouncingScrollPhysics(),
          children: <Widget>[



            RefreshIndicator(
              onRefresh: fetchData,
              color: TYColor.primary,
              child:MediaQuery.removePadding(
                removeTop: true,
                context: context,
                child: ListView.builder(
                  //controller: scrollController,
                  itemCount: 4,
                  itemBuilder: (BuildContext context, int index) {
                    return buildPersonal(context, index);
                  },
                ),
              )
            ),

          ],
        ),
      ),
//      body: Container(
//        color: Colors.white,
//        child: ListView(
//          physics: BouncingScrollPhysics(),
//          children: <Widget>[
//            MeHeader(),
//            SizedBox(height: 10),
//            buildCells(context),
//          ],
//        ),
//      ),
    );
  }
}




///个人数据
Widget buildPersonal(BuildContext context, int index) {
  Widget widget;
  switch (index) {
    case 0:

      widget = MeScene.sharedInstance().buildbackground(context);//背景
      break;
    case 1:
      widget = MeHeader();//等级，金币
      break;
    case 2:
      widget = MeScene.sharedInstance().buildImportant(context);//按钮
      break;
    case 3:
     widget = MeScene.sharedInstance().buildCells(context);//我的书架
      break;
    case 4:
     // widget = ComicUpdateTodayView(updateTodayList);///今日我更新
      break;
  }
  return widget;
}

