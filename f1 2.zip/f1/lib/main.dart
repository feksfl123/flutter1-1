import 'package:flutter/material.dart';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:tianyue/app/app_scene.dart';
import 'app/request.dart';
import 'package:dio/dio.dart';


void main() async{
//  Dio dio = Dio();
// // Request.getBatteryuuid();
//  var response1 = await dio.post("http://192.168.1.197:8088/api/user/traveler", data: {"deviceId": "996", "deviceType": "2","registerip": "3"});
//  //String platformImei = await ImeiPlugin.getImei( shouldShowRequestPermissionRationale: false );
//  response1.headers.set("Authorization",
//      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJwdWJsaWMiLCJleHAiOjE1Nzk5NjMwMDQsImlzcyI6ImNvbS5idXR0ZXJmbHkiLCJzdWIiOiJhc2lnbiIsInVzZXJJZCI6MX0.ri2LgjPySK40W6djxAoZdb9zcw3NiZTBrfUkfAgqW-c");

  runApp(AppScene());


  if (Platform.isAndroid) {
    SystemUiOverlayStyle systemUiOverlayStyle =
        SystemUiOverlayStyle(statusBarColor: Colors.transparent);
    SystemChrome.setSystemUIOverlayStyle(systemUiOverlayStyle);
  }
}



//
//class MyApp extends StatefulWidget {
//  @override
//  _MyAppState createState() => _MyAppState();
//}
//
//class _MyAppState extends State<MyApp> {
//  String _platformImei = 'Unknown';
//
//  @override
//  void initState() {
//    super.initState();
//    getDeviceInfo();
//  }
//  void getDeviceInfo() async {
//    DeviceInfoPlugin deviceInfo = new DeviceInfoPlugin();
//    if(Platform.isAndroid) {
//      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
//      print('1');
//    } else if (Platform.isIOS) {
//      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
//      print('2');
//    }
//  }
//
//  @override
//  Widget build(BuildContext context) {
//    return MaterialApp(
//      home: Scaffold(
//        appBar: AppBar(
//          title: const Text('Plugin example app'),
//        ),
//        body: Center(
//          child: Text('Running on: $_platformImei\n'),
//        ),
//      ),
//    );
//  }
//}
