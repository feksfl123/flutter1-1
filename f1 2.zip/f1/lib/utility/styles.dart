import 'package:flutter/material.dart';

class Styles {
  static List<BoxShadow> get borderShadow {
    return [BoxShadow(color: Color(0x22000000), blurRadius: 8)];
  }
}