class Constant{
  static const String comicBlock = "无良推荐";

  static const String recommendEveryDay = "每日一推";

  static const String updateToday = "今日我更新";
}