// 所有 BLoCs 的通用接口
abstract class BlocBase {
  void dispose();
}