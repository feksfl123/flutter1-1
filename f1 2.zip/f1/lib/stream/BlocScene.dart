import 'dart:async';
//import 'dart:html';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rxdart/rxdart.dart';
import 'package:tianyue/public.dart';
import 'package:tianyue/stream/BlocProvider.dart';
import 'package:tianyue/stream/CounterWidget.dart';
import 'package:tianyue/stream/CounterStream.dart';
import 'package:tianyue/stream/IncrementBloc.dart';
import 'package:tianyue/widget/loading_indicator.dart';

class bookshelfScene extends StatelessWidget {///书架
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("欢迎来到书架"),
          elevation: 0,
        ),
        body: Center(
          child: Text("欢迎来到书架")
        )
    );
  }
}




class recordScene extends StatelessWidget {///购买记录
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("欢迎来到购买记录"),
          elevation: 0,
        ),
        body: Center(
            child: Text("欢迎来到购买记录")
        )
    );
  }
}




class proxyScene extends StatelessWidget {///代理赚钱
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("欢迎来到代理赚钱"),
          elevation: 0,
        ),
        body: Center(
            child: Text("欢迎来到代理赚钱")
        )
    );
  }
}


class plusgroupScene extends StatelessWidget {///加群开车
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("欢迎来到加群开车"),
          elevation: 0,
        ),
        body: Center(
            child: Text("欢迎来到加群开车")
        )
    );
  }
}




class helpScene extends StatelessWidget {///帮助
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("欢迎来到帮助"),
          elevation: 0,
        ),
        body: Center(
            child: Text("欢迎来到帮助")
        )
    );
  }
}



class exchangeScene extends StatelessWidget {///兑换码
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("欢迎来到兑换码"),
          elevation: 0,
        ),
        body: Center(
            child: Text("欢迎来到兑换码")
        )
    );
  }
}







