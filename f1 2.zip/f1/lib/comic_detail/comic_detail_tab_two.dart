
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tianyue/comic_home/comic_block_item_view.dart';
import 'package:tianyue/public.dart';

class ComicChapterTabTwo extends StatelessWidget {
  final ComicChapter comicChapter;

  ComicChapterTabTwo(this.comicChapter);

  Widget buildChapterWidget(BuildContext context, String chapterName) {
    return GestureDetector(
        onTap: () {
          AppNavigator.pushComicReader(context, "");
        },
        child: Container(
            decoration: BoxDecoration(
              color: Colors.black12,
              borderRadius: BorderRadius.circular(5),
            ),
            alignment: Alignment.center,
            child: Text(chapterName,
                style: TextStyle(
                    fontSize: 17,
                    color: TYColor.gray,
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.none))));
  }

  @override
  Widget build(BuildContext context) {
    if (comicChapter == null ||
        CollectionsUtils.isEmpty(comicChapter.recommendList)) {
      return Container();
    }
    var chapterChildren = comicChapter.categoryList
        .map((chapterName) => buildChapterWidget(context, chapterName))
        .toList();
    var recommendChildren = comicChapter.recommendList
        .map((comicItem) => ComicBlockItemView(comicItem, Color(0xFFF5F5EE)))
        .toList();
    return SingleChildScrollView(
        child: Column(
          children: <Widget>[
            SizedBox(height: 20,),
            Container(
              child: Row(children: <Widget>[
                SizedBox(width: 17,),
                Text('连载',style: TextStyle(fontWeight: FontWeight.w600,fontSize: 19),),
                Container(
                    child: Text(comicChapter.updateTime,
                        style: TextStyle(
                            fontSize: 12,
                            color: TYColor.gray,
                            fontWeight: FontWeight.w300,
                            decoration: TextDecoration.none)),
                    padding: EdgeInsets.fromLTRB(15, 10, 10, 0)),

                SizedBox(width: MediaQuery.of(context).size.width/3.5,),
                Text('全部',style: TextStyle(color:Colors.pink,fontSize: 15),),
                Stack(children: <Widget>[
                    Icon(Icons.fiber_manual_record,color: Colors.pink,size: 22,),
                    Icon(Icons.navigate_next,color: Colors.white,size: 22,),
                ],)


              ],),
            ),

            GridView(
                padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 5,
                    crossAxisCount: 4,
                    childAspectRatio: 2.4),
                children: chapterChildren,
                // 防止在row，column中不显示
                shrinkWrap: true,
                // 处理滑动冲突
                physics: NeverScrollableScrollPhysics()),


            ///点赞
            Container(
                width: MediaQuery.of(context).size.width,
                child: Row(
                  children: <Widget>[
                    Container(
                        width: MediaQuery.of(context).size.width/4,
                        height: 120,
                        child: Stack(
                          children: <Widget>[
                            Positioned(
                                left: 18,
                                child:GestureDetector(
                                  child: Image.asset('img/praise1.png',
                                    width: 70,height: 70,
                                  ),

                                  onTap: (){},
                                )
                            ),
                            Positioned(
                              left:15,
                              bottom: 26,
                              child: Text('好看的一匹'),
                            ),
                            Positioned(
                              left:35,
                              bottom: 5,
                              child: Text('2951'),
                            )
                          ],
                        )

                    ),
                    Container(
                        width: MediaQuery.of(context).size.width/4,
                        height: 120,
                        child: Stack(
                          children: <Widget>[
                            Positioned(
                                left: 15,
                                child:GestureDetector(
                                  child: Image.asset('img/praise2.png',width: 70,height: 70,),

                                  onTap: (){},
                                )
                            ),
                            Positioned(
                              left: 35,
                              bottom: 26,
                              child: Text('必须赞'),
                            ),
                            Positioned(
                              left:37,
                              bottom: 5,
                              child: Text('2686'),
                            )
                          ],
                        )

                    ),
                    Container(
                        width: MediaQuery.of(context).size.width/4,
                        height: 120,
                        child: Stack(
                          children: <Widget>[
                            Positioned(
                                left: 15,
                                child:GestureDetector(
                                  child: Image.asset('img/praise3.png',width: 70,height: 70,),

                                  onTap: (){},
                                )
                            ),
                            Positioned(
                              left: 30,
                              bottom: 26,
                              child: Text('神马鬼'),
                            ),
                            Positioned(
                              left:35,
                              bottom: 5,
                              child: Text('250'),
                            )
                          ],
                        )

                    ),
                    SizedBox(height: 10,),
                    Container(
                        width: MediaQuery.of(context).size.width/4,
                        height: 120,
                        child: Stack(
                          children: <Widget>[
                            Positioned(
                                left: 15,
                                child:GestureDetector(
                                  child: Image.asset('img/praise4.png',width: 70,height: 70,),

                                  onTap: (){},
                                )
                            ),
                            Positioned(
                              left: 25,
                              bottom: 26,
                              child: Text('不好看'),
                            ),
                            Positioned(
                              left:35,
                              bottom: 5,
                              child: Text('141'),
                            )
                          ],
                        )

                    ),

                  ],
                )
            ),
            Container(
              child: Text("骚年们都在看",
                  style: TextStyle(
                      fontSize: 15,
                      color: TYColor.gray,
                      fontWeight: FontWeight.w300,
                      decoration: TextDecoration.none)),
              padding: EdgeInsets.only(left: 15),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(15, 15, 0, 15),
              child: Wrap(
                  spacing: 15, runSpacing: 15, children: recommendChildren),
            ),
          ],
          crossAxisAlignment: CrossAxisAlignment.start,
        ),
        physics: NeverScrollableScrollPhysics());
  }
}
