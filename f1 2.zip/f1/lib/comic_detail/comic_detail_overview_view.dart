import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:tianyue/public.dart';

class ComicDetailOverViewView extends StatelessWidget {
  final ComicOverview comicOverview;

  ComicDetailOverViewView(this.comicOverview);

  @override
  Widget build(BuildContext context) {
    if (comicOverview == null) {
      return Container();
    }
    var width = Screen.width;
    var height = width * 0.5;
    return Container(
      width: width,
      height: MediaQuery.of(context).size.height/3.5,
      child: Stack(
        children: <Widget>[
          NovelCoverImage(
            comicOverview.cover,
            width: MediaQuery.of(context).size.width,
            height: height,
            fit: BoxFit.cover,
          ),
          ClipRect(
            child: BackdropFilter(
              filter: ui.ImageFilter.blur(sigmaX: 1.0,sigmaY: 5.0),
              child: Opacity(
                opacity: 0.4,//透明度，
                child: Container(//.grey.shade100
                  width: MediaQuery.of(context).size.width,
                  height: height,
                  decoration: BoxDecoration(color:Colors.black),
                ),
              ),
            ),

          ),


          BackdropFilter(
            filter: new ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: new Container(
              //color: Colors.transparent.withOpacity(0),
              width: width,
              height: height,
            ),
          ),
          Positioned(
            bottom: 0,
            child: Row(
              children: <Widget>[
                SizedBox(width: 30),
                NovelCoverImage(
                  comicOverview.cover,
                  width: width * 0.32,
                  height: width * 0.42,
                ),
                SizedBox(width: 20),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(height: 20),

                    Row(children: <Widget>[
                      Text(comicOverview.title,
                          style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              decoration: TextDecoration.none)),
                      SizedBox(width: 5),
                      Container(
                        child: Text(
                          comicOverview.score,
                          style: TextStyle(
                              fontSize: 11,
                              color: Colors.white,
                              decoration: TextDecoration.none),
                          textAlign: TextAlign.center,
                        ),
                        decoration: BoxDecoration(
                          color: TYColor.primary,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        alignment: Alignment.center,
                        width: 24,
                        height: 24,
                      )
                    ]),
                    SizedBox(width: 20),

                    Container(
                      width: 220,
                      height: 60,
                      child: Text('(平台独家原创) 谁能想到，如今黑白两道叱咤风云的商业巨子侯龙涛，曾经就是你我身边随处可见的小混...'
                          ,maxLines: 3,overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          )),
                    ),
                    SizedBox(height: 50),
                    Row(children: <Widget>[
                      Text("人气：${comicOverview.popularity}",
                          style: TextStyle(
                              fontSize: 15,
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              decoration: TextDecoration.none)),
                      SizedBox(width: 20,),
                      Text("热度：${comicOverview.monthTicket}",
                          style: TextStyle(
                              fontSize: 15,
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              decoration: TextDecoration.none)),

                    ],),

                  ],
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
